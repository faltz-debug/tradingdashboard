'use strict';

/**
 * FILTERS — Funções de filtro e contexto para o motor de sinal VIP.
 *
 * Este módulo contém os filtros de trading extraídos do server.js.
 * Todas as funções são puras: mesma entrada → mesma saída, sem I/O, sem cache global.
 *
 * Dependência: calcEMA importado de ./indicators (funções de indicadores técnicos puros).
 *
 * Funções exportadas:
 *   - emaAligned(closes, direction)                          → bool
 *   - hasBreakout(candles, direction, bars = 20)             → bool
 *   - hasInsideBar(candles, direction)                       → bool
 *   - hasVolumeConfirmation(candles, multiplier = 1.1)       → bool | null
 *   - hasBollingerSqueeze(closes, period = 20, lb = 20)      → bool
 *   - getEma200Context(candles, direction)                   → { ema200, aligned } | null
 *   - hasPullbackEma20(candles, direction)                   → bool
 *   - detectCMEGap(candles)                                  → object | null
 *   - getBiasTf(candles)                                     → 'BUY' | 'SELL' | 'NEUTRAL'
 *
 * Formato esperado de candles: { open, high, low, close, volume?, time?, timestamp? }
 * Não modificam o array de entrada nem qualquer estado externo.
 */

const { calcEMA } = require('./indicators');

// ─── EMA ALIGNMENT ───────────────────────────────────────────────────────────

/**
 * Verifica se as EMAs estão alinhadas para a direção dada
 * BUY:  ema9 > ema20 > ema50
 * SELL: ema9 < ema20 < ema50
 */
function emaAligned(closes, direction) {
  const ema9  = calcEMA(closes, 9);
  const ema20 = calcEMA(closes, 20);
  const ema50 = calcEMA(closes, 50);
  if (!ema9 || !ema20 || !ema50) return false;
  if (direction === 'BUY')  return ema9 > ema20 && ema20 > ema50;
  if (direction === 'SELL') return ema9 < ema20 && ema20 < ema50;
  return false;
}

// ─── BREAKOUT ────────────────────────────────────────────────────────────────

/**
 * Verifica breakout das últimas N velas (fecha acima/abaixo do máximo/mínimo anterior)
 * BUY:  close > max(highs) dos últimos N bars
 * SELL: close < min(lows) dos últimos N bars
 */
function hasBreakout(candles, direction, bars = 20) {
  if (candles.length < bars + 1) return false;
  const lookback = candles.slice(candles.length - bars - 1, candles.length - 1);
  const last = candles[candles.length - 1];
  if (direction === 'BUY')  return last.close > Math.max(...lookback.map(c => c.high));
  if (direction === 'SELL') return last.close < Math.min(...lookback.map(c => c.low));
  return false;
}

// ─── INSIDE BAR ──────────────────────────────────────────────────────────────

/**
 * FILTRO BÔNUS 1 — Inside Bar (Compressão)
 * Detecta padrão de 3 velas: mãe → inside bar → confirmação de rompimento
 *   candles[-3] = vela mãe (maior range)
 *   candles[-2] = inside bar (contida dentro da mãe)
 *   candles[-1] = confirmação (fecha acima da máxima da mãe em BUY, abaixo da mínima em SELL)
 *
 * Por que funciona: inside bar = compressão de volatilidade. O mercado "respira" antes de
 * uma decisão direcional. Quando o preço rompe a mãe com confirmação de fechamento,
 * o movimento tende a ser mais limpo que um breakout simples de 30 períodos.
 */
function hasInsideBar(candles, direction) {
  if (candles.length < 3) return false;
  const mother  = candles[candles.length - 3];
  const inside  = candles[candles.length - 2];
  const confirm = candles[candles.length - 1];

  // inside bar deve estar ESTRITAMENTE contida dentro da vela mãe
  // (definicao classica — empate de high ou low nao conta como inside bar
  // porque nao representa compressao real de range)
  const isInsideBar = inside.high < mother.high && inside.low > mother.low;
  if (!isInsideBar) return false;

  // confirmação deve fechar além do range da inside bar na direção correta
  // (verificar contra inside.high/low é suficiente — exigir ultrapassar a mãe inteira era muito estrito)
  if (direction === 'BUY')  return confirm.close > inside.high;
  if (direction === 'SELL') return confirm.close < inside.low;
  return false;
}

// ─── VOLUME CONFIRMATION ─────────────────────────────────────────────────────

/**
 * FILTRO BÔNUS 2 — Confirmação de Volume
 * Verifica se o volume da vela atual está acima da média dos últimos 20 períodos.
 * Retorna null se não houver dados de volume disponíveis (sem penalidade).
 *
 * Por que importa: breakout com volume alto = mercado participando da direção.
 * Breakout com volume fraco = maior probabilidade de false breakout.
 * Para forex spot o volume é tick volume (proxy), mas ainda tem valor relativo.
 */
function hasVolumeConfirmation(candles, multiplier = 1.1) {
  if (candles.length < 21) return null;
  const current = candles[candles.length - 1];
  if (!current.volume || current.volume === 0) return null;  // sem dados → sem penalidade
  const lookback = candles.slice(-21, -1);
  const avgVol = lookback.reduce((sum, c) => sum + (c.volume || 0), 0) / lookback.length;
  if (avgVol === 0) return null;
  return current.volume >= avgVol * multiplier;
}

// ─── BOLLINGER SQUEEZE ───────────────────────────────────────────────────────

/**
 * FILTRO BÔNUS 3 — Bollinger Band Squeeze
 * Detecta compressão das Bollinger Bands: largura atual abaixo de 85% da média
 * dos últimos 20 cálculos. Indica mercado em consolidação antes de expansão.
 *
 * Por que funciona: squeeze + breakout = setup de maior qualidade.
 * O mercado "carrega energia" durante a compressão e libera no rompimento.
 * Especialmente relevante para EUR/USD (alta liquidez + padrões técnicos limpos).
 */
function hasBollingerSqueeze(closes, period = 20, lookbackWindows = 20) {
  if (closes.length < period + lookbackWindows) return false;

  const widths = [];
  // Calcula largura normalizada da BB para as últimas lookbackWindows+1 janelas
  for (let i = 0; i <= lookbackWindows; i++) {
    const end   = closes.length - i;
    const start = end - period;
    if (start < 0) break;
    const slice = closes.slice(start, end);
    const sma   = slice.reduce((a, b) => a + b, 0) / period;
    if (sma === 0) { widths.push(0); continue; }
    const variance = slice.reduce((a, b) => a + Math.pow(b - sma, 2), 0) / period;
    const std = Math.sqrt(variance);
    widths.push((4 * std) / sma);  // largura normalizada como % do preço
  }

  if (widths.length < 2) return false;
  const currentWidth = widths[0];  // i=0 → janela mais recente
  const avgWidth = widths.slice(1).reduce((a, b) => a + b, 0) / (widths.length - 1);

  // Squeeze: largura atual pelo menos 10% abaixo da média recente (era 15%, muito restritivo)
  return currentWidth > 0 && avgWidth > 0 && currentWidth < avgWidth * 0.90;
}

// ─── EMA 200 CONTEXT ─────────────────────────────────────────────────────────

/**
 * CONTEXTO MACRO — EMA 200 (XAU/USD)
 * Calcula EMA 200 e verifica se o preço está do lado correto para a direção.
 * Retorna null se dados insuficientes.
 * Não pontua no score — aparece como contexto operacional (aviso ou confirmação).
 */
function getEma200Context(candles, direction) {
  if (!candles || candles.length < 200) return null;
  const closes = candles.map(c => c.close);
  const ema200 = calcEMA(closes, 200);
  const price  = closes[closes.length - 1];
  const aligned = direction === 'BUY' ? price > ema200 : price < ema200;
  return { ema200: parseFloat(ema200.toFixed(2)), aligned };
}

// ─── PULLBACK EMA20 ──────────────────────────────────────────────────────────

/**
 * FILTRO BÔNUS — Pullback EMA20 com confirmação
 * Detecta quando o preço retornou à EMA20 numa tendência alinhada e formou
 * uma vela de confirmação forte na direção da tendência.
 *
 * Condições BUY:
 *   1. EMAs alinhadas: EMA9 > EMA20 > EMA50 (tendência bullish confirmada)
 *   2. Vela anterior tocou a EMA20 (dentro de ±0.4%)
 *   3. Vela atual é bullish forte: fecha acima do EMA9 com corpo expressivo
 *
 * Por que funciona: em tendências saudáveis, o preço recua à EMA20 antes de
 * continuar. Entrar no pullback vs no topo dá uma relação R:R muito melhor.
 * É mais seletivo que o breakout simples — filtra entradas em extensão.
 */
function hasPullbackEma20(candles, direction) {
  if (candles.length < 3) return false;

  const closes = candles.map(c => c.close);
  const ema9  = calcEMA(closes, 9);
  const ema20 = calcEMA(closes, 20);
  const ema50 = calcEMA(closes, 50);

  // 1. EMAs devem estar alinhadas para a direção
  const alignedBuy  = ema9 > ema20 && ema20 > ema50;
  const alignedSell = ema9 < ema20 && ema20 < ema50;
  if (direction === 'BUY'  && !alignedBuy)  return false;
  if (direction === 'SELL' && !alignedSell) return false;

  // 2. Vela anterior tocou a EMA20 (±0.8% de tolerância)
  const prev  = candles[candles.length - 2];
  const prevCloses = closes.slice(0, -1);
  const ema20prev  = calcEMA(prevCloses, 20);
  const touchedEma20 = Math.abs(prev.close - ema20prev) / (ema20prev || 1) < 0.008
                    || Math.abs(prev.low   - ema20prev) / (ema20prev || 1) < 0.008  // BUY: low tocou
                    || Math.abs(prev.high  - ema20prev) / (ema20prev || 1) < 0.008; // SELL: high tocou

  if (!touchedEma20) return false;

  // 3. Vela atual confirma: corpo expressivo na direção certa, fecha além da EMA9
  const curr      = candles[candles.length - 1];
  const bodySize  = Math.abs(curr.close - curr.open);
  const range     = curr.high - curr.low;
  const strongBody = range > 0 && bodySize / range >= 0.5;  // corpo ≥ 50% do range total

  if (direction === 'BUY')  return curr.close > curr.open && curr.close > ema9 && strongBody;
  if (direction === 'SELL') return curr.close < curr.open && curr.close < ema9 && strongBody;
  return false;
}

// ─── CME GAP ─────────────────────────────────────────────────────────────────

/**
 * CONTEXTO — CME Gap para BTC
 * Os futuros CME de Bitcoin fecham toda sexta ~21:00 UTC e reabrem domingo ~23:00 UTC.
 * Qualquer diferença de preço entre o fechamento de sexta e a abertura de domingo
 * é chamado de "CME Gap". Estatisticamente ~80% desses gaps são preenchidos.
 *
 * Retorna:
 *   gapDirection:    'UP' (preço abriu acima) | 'DOWN' (abriu abaixo)
 *   fillerDirection: direção que PREENCHE o gap ('BUY' para gap DOWN, 'SELL' para gap UP)
 *   gapFilled:       true se o preço atual já voltou à zona do gap
 *   fillTarget:      preço de fechamento da sexta (alvo de preenchimento)
 *
 * Não pontua diretamente — aparece como contexto estratégico no meta.
 * Mas quando a direção do sinal == fillerDirection, adiciona bônus de contexto.
 */
function detectCMEGap(candles) {
  if (!candles || candles.length < 10) return null;

  let fridayClose = null;
  let sundayOpen  = null;

  // Percorre candles do mais recente para o mais antigo
  for (let i = candles.length - 1; i >= 0; i--) {
    const c  = candles[i];
    const ts = typeof c.timestamp === 'number' ? c.timestamp : (c.time ? c.time * 1000 : null);
    if (!ts) continue;
    const d   = new Date(ts);
    const day = d.getUTCDay();   // 0=Dom, 1=Seg, ..., 5=Sex, 6=Sáb
    const hr  = d.getUTCHours();

    // Janela de fechamento CME: sexta 20:00-22:00 UTC
    if (day === 5 && hr >= 20 && hr <= 22 && !fridayClose) {
      fridayClose = { price: c.close, ts };
    }
    // Janela de reabertura CME: domingo 22:00-24:00 UTC
    if (day === 0 && hr >= 22 && !sundayOpen) {
      sundayOpen = { price: c.open ?? c.close, ts };
    }

    if (fridayClose && sundayOpen) break;
  }

  if (!fridayClose || !sundayOpen) return null;
  if (fridayClose.ts >= sundayOpen.ts) return null;  // ordem temporal inválida

  const gapSize = sundayOpen.price - fridayClose.price;
  const gapPct  = (gapSize / fridayClose.price) * 100;

  if (Math.abs(gapPct) < 0.3) return null;  // gap menor que 0.3% → irrelevante

  const currentPrice    = candles[candles.length - 1].close;
  const gapDirection    = gapSize > 0 ? 'UP' : 'DOWN';
  const fillerDirection = gapDirection === 'DOWN' ? 'BUY' : 'SELL';

  // Gap preenchido quando preço voltou ao nível do fechamento de sexta
  const gapFilled = gapDirection === 'UP'
    ? currentPrice <= fridayClose.price
    : currentPrice >= fridayClose.price;

  return {
    gapSize:          parseFloat(gapSize.toFixed(2)),
    gapPct:           parseFloat(gapPct.toFixed(2)),
    gapDirection,
    fillerDirection,
    fridayClose:      fridayClose.price,
    sundayOpen:       sundayOpen.price,
    fillTarget:       fridayClose.price,
    gapFilled,
    // Alinhado = sinal atual está na direção que preenche o gap
    alignedWithSignal: null,  // preenchido em computeVipSignal
  };
}

// ─── BIAS (EMA 9/20/50) ──────────────────────────────────────────────────────

/**
 * Determina o viés direcional (BUY/SELL/NEUTRAL) baseado nas EMAs 9/20/50
 */
function getBiasTf(candles) {
  if (!candles || candles.length < 30) return 'NEUTRAL';
  const closes = candles.map(c => c.close);
  const ema9   = calcEMA(closes, 9);
  const ema20  = calcEMA(closes, 20);
  const ema50  = calcEMA(closes, 50);
  if (ema9 > ema20 && ema20 > ema50) return 'BUY';
  if (ema9 < ema20 && ema20 < ema50) return 'SELL';
  return 'NEUTRAL';
}

// ─── EXPORTS ──────────────────────────────────────────────────────────────────

module.exports = {
  emaAligned,
  hasBreakout,
  hasInsideBar,
  hasVolumeConfirmation,
  hasBollingerSqueeze,
  getEma200Context,
  hasPullbackEma20,
  detectCMEGap,
  getBiasTf,
};
