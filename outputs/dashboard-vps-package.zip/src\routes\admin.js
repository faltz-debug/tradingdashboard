'use strict';

/**
 * src/routes/admin.js
 *
 * Roteador Express com as 7 rotas administrativas:
 *   POST  /api/admin/weekly-report               — dispara relatorio semanal manual
 *   GET   /api/admin/users                       — lista usuarios (filtros: accessStatus/role)
 *   POST  /api/admin/users                       — cria usuario via admin
 *   PATCH /api/admin/users/:id                   — atualiza usuario
 *   POST  /api/admin/users/:id/revoke-sessions   — revoga todas as sessoes
 *   GET   /api/admin/auto-trade/status           — estado do auto-trade + cooldowns
 *   POST  /api/admin/auto-trade/toggle           — liga/desliga auto-trade em runtime
 *
 * Padrao de injecao identico ao routes/auth.js.
 *
 * @param {object} deps
 * @param {object} deps.authStore
 * @param {object} deps.scheduler                 — getAutoTradeEnabled / setAutoTradeEnabled / getAutoTradeLastAt
 * @param {Function} deps.sendWeeklyReport
 * @param {Function} deps.sendTelegram
 * @param {Function} deps.rateLimit
 * @param {Function} deps.requireAdmin
 * @param {Function} deps.buildPublicUser
 * @param {object}   deps.logger
 * @param {object}   deps.config
 * @param {boolean}  deps.config.BOT_WEBHOOK_ENABLED
 * @param {number}   deps.config.AUTO_OPEN_SCORE_THRESHOLD
 * @param {number}   deps.config.AUTO_TRADE_COOLDOWN_MS
 *
 * @returns {import('express').Router}
 */

const express = require('express');
const axios = require('axios');

const BOT_STATUS_URL = process.env.BOT_STATUS_URL || 'http://localhost:5000/status';
const BOT_WEBHOOK_TOKEN = process.env.BOT_WEBHOOK_TOKEN || '';

function getBotBaseUrl() {
  try {
    const u = new URL(BOT_STATUS_URL);
    return `${u.protocol}//${u.host}`;
  } catch {
    return 'http://localhost:5000';
  }
}

function createAdminRouter(deps) {
  const {
    authStore,
    scheduler,
    sendWeeklyReport,
    sendTelegram,
    rateLimit,
    requireAdmin,
    buildPublicUser,
    logger,
    config,
  } = deps;

  const {
    BOT_WEBHOOK_ENABLED,
    AUTO_OPEN_SCORE_THRESHOLD,
    AUTO_TRADE_COOLDOWN_MS,
    AUTO_TRADE_MAX_PER_ASSET,
    AUTO_TRADE_PYRAMID_COOLDOWN_MS,
  } = config;

  const router = express.Router();

  // ── Relatorio semanal sob demanda ───────────────────────────────────────
  router.post('/weekly-report', rateLimit, requireAdmin, async (req, res) => {
    try {
      await sendWeeklyReport();
      res.json({ success: true, message: 'Relatório semanal enviado via Telegram' });
    } catch (e) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  // ── CRUD de usuarios ────────────────────────────────────────────────────
  router.get('/users', rateLimit, requireAdmin, (req, res) => {
    const { accessStatus, role, limit } = req.query;
    const users = authStore.listUsers({
      accessStatus: accessStatus ? String(accessStatus) : undefined,
      role: role ? String(role) : undefined,
      limit: parseInt(limit, 10) || 100,
    });
    res.json({ success: true, count: users.length, users });
  });

  router.post('/users', rateLimit, requireAdmin, (req, res) => {
    const {
      email,
      password,
      role = 'subscriber',
      accessStatus = 'active',
      planCode = 'vip',
      name,
      telegramHandle,
      notes,
    } = req.body || {};

    try {
      const user = authStore.createUser({
        email,
        password,
        role,
        accessStatus,
        planCode,
        profile: { name, telegramHandle, notes, createdVia: 'admin' },
      });
      res.status(201).json({ success: true, user: buildPublicUser(user) });
    } catch (err) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  router.patch('/users/:id', rateLimit, requireAdmin, (req, res) => {
    const { id } = req.params;
    const {
      email,
      password,
      role,
      accessStatus,
      planCode,
      name,
      telegramHandle,
      notes,
      revokeSessions,
    } = req.body || {};

    try {
      const updated = authStore.updateUser(id, {
        email,
        password,
        role,
        accessStatus,
        planCode,
        profile: { name, telegramHandle, notes },
      });

      if (!updated) {
        return res.status(404).json({ success: false, error: 'Usuario nao encontrado' });
      }

      if (revokeSessions || password != null || accessStatus === 'canceled' || accessStatus === 'inactive') {
        authStore.revokeSessionsForUser(id);
      }

      res.json({ success: true, user: buildPublicUser(updated) });
    } catch (err) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  router.post('/users/:id/revoke-sessions', rateLimit, requireAdmin, (req, res) => {
    const { id } = req.params;
    const revoked = authStore.revokeSessionsForUser(id);
    res.json({ success: true, revoked });
  });

  // ── AUTO-TRADE toggle ───────────────────────────────────────────────────
  router.get('/auto-trade/status', rateLimit, requireAdmin, (req, res) => {
    const lastAt = scheduler.getAutoTradeLastAt();
    res.json({
      autoTradeEnabled:   scheduler.getAutoTradeEnabled(),
      pyramidEnabled:     scheduler.getPyramidEnabled(),
      webhookEnabled:     BOT_WEBHOOK_ENABLED,
      scoreThreshold:     AUTO_OPEN_SCORE_THRESHOLD,
      cooldownHours:      AUTO_TRADE_COOLDOWN_MS / 3600000,
      maxPerAsset:        AUTO_TRADE_MAX_PER_ASSET,
      pyramidCooldownMin: AUTO_TRADE_PYRAMID_COOLDOWN_MS / 60000,
      lastTrades: Object.fromEntries(
        Object.entries(lastAt).map(([k, v]) => [k, new Date(v).toISOString()])
      ),
    });
  });

  router.post('/auto-trade/pyramid', rateLimit, requireAdmin, (req, res) => {
    const { enabled } = req.body || {};
    if (typeof enabled !== 'boolean') {
      return res.status(400).json({ success: false, error: '"enabled" deve ser true ou false' });
    }
    scheduler.setPyramidEnabled(enabled);
    const state = enabled ? 'LIGADO' : 'DESLIGADO';
    logger.info(`Pyramid mode ${state} por ${req.auth?.user?.email || 'admin'}`);
    sendTelegram([
      `🔺 <b>Pyramid Mode ${state}</b>`,
      enabled
        ? `Ate ${AUTO_TRADE_MAX_PER_ASSET} trades por ativo | cooldown ${AUTO_TRADE_PYRAMID_COOLDOWN_MS/60000}min`
        : `Modo normal: 1 trade por ativo`,
    ].join('\n')).catch(() => {});
    res.json({ success: true, pyramidEnabled: scheduler.getPyramidEnabled() });
  });

  router.post('/auto-trade/toggle', rateLimit, requireAdmin, (req, res) => {
    const { enabled } = req.body || {};
    if (typeof enabled !== 'boolean') {
      return res.status(400).json({ success: false, error: '"enabled" deve ser true ou false' });
    }

    scheduler.setAutoTradeEnabled(enabled);
    const state = enabled ? '🟢 LIGADO' : '🔴 DESLIGADO';
    logger.info(`Auto-trade ${state} por ${req.auth?.user?.email || 'admin'}`);

    // Notifica no Telegram também
    sendTelegram(`⚙️ <b>Auto-Trade ${state}</b>\n<i>Alterado pelo painel admin</i>`).catch(() => {});

    res.json({ success: true, autoTradeEnabled: scheduler.getAutoTradeEnabled() });
  });

    // ── TRAILING STOP toggle ────────────────────────────────────────────────
  router.get('/trailing-stop/status', rateLimit, requireAdmin, (req, res) => {
    res.json({ success: true, trailingStopEnabled: scheduler.getTrailingStopEnabled() });
  });

  router.post('/trailing-stop/toggle', rateLimit, requireAdmin, (req, res) => {
    const { enabled } = req.body || {};
    if (typeof enabled !== 'boolean') {
      return res.status(400).json({ success: false, error: '"enabled" deve ser true ou false' });
    }
    scheduler.setTrailingStopEnabled(enabled);
    const state = enabled ? '🟢 LIGADO' : '🔴 DESLIGADO';
    logger.info(`Trailing Stop ${state} por ${req.auth?.user?.email || 'admin'}`);
    sendTelegram(`📐 <b>Trailing Stop ${state}</b>\n<i>Alterado pelo painel admin</i>`).catch(() => {});
    res.json({ success: true, trailingStopEnabled: scheduler.getTrailingStopEnabled() });
  });

  // ── RESET de operações (apaga todos os trades/sinais) ───────────────────
  router.get('/profit-lock/status', rateLimit, requireAdmin, async (req, res) => {
    try {
      const headers = {};
      if (BOT_WEBHOOK_TOKEN) headers['x-webhook-token'] = BOT_WEBHOOK_TOKEN;
      const resp = await axios.get(`${getBotBaseUrl()}/config/profit-lock`, { headers, timeout: 5000 });
      const data = resp.data || {};
      res.json({
        success: true,
        profitLockEnabled: !!data.profitLockEnabled,
        triggerPct: data.triggerPct,
        securePct: data.securePct,
      });
    } catch (err) {
      res.status(502).json({ success: false, error: err.response?.data?.error || err.message });
    }
  });

  router.post('/profit-lock/toggle', rateLimit, requireAdmin, async (req, res) => {
    const { enabled } = req.body || {};
    if (typeof enabled !== 'boolean') {
      return res.status(400).json({ success: false, error: '"enabled" deve ser true ou false' });
    }
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (BOT_WEBHOOK_TOKEN) headers['x-webhook-token'] = BOT_WEBHOOK_TOKEN;
      const resp = await axios.post(`${getBotBaseUrl()}/config/profit-lock`, { enabled }, { headers, timeout: 5000 });
      const data = resp.data || {};
      const state = data.profitLockEnabled ? '🟢 LIGADO' : '🔴 DESLIGADO';
      logger.info(`Profit Lock ${state} por ${req.auth?.user?.email || 'admin'}`);
      sendTelegram(`🔐 <b>Profit Lock ${state}</b>\n<i>80% do alvo -> trava 20% do ganho</i>\n<i>Alterado pelo painel admin</i>`).catch(() => {});
      res.json({
        success: true,
        profitLockEnabled: !!data.profitLockEnabled,
        triggerPct: data.triggerPct,
        securePct: data.securePct,
      });
    } catch (err) {
      res.status(502).json({ success: false, error: err.response?.data?.error || err.message });
    }
  });

  router.get('/bot-status', rateLimit, requireAdmin, async (req, res) => {
    try {
      const headers = {};
      if (BOT_WEBHOOK_TOKEN) headers['x-webhook-token'] = BOT_WEBHOOK_TOKEN;
      const botResp = await axios.get(`${getBotBaseUrl()}/status`, { headers, timeout: 5000 });
      const bot = botResp.data || {};
      const profit = bot.profit_lock || {};
      res.json({
        success: true,
        botStatus: bot.bot_status || 'UNKNOWN',
        account: bot.account || null,
        positions: Array.isArray(bot.positions) ? bot.positions : [],
        profitLockEnabled: !!profit.profitLockEnabled,
        profitLockTriggerPct: profit.triggerPct,
        profitLockSecurePct: profit.securePct,
        autoTradeEnabled: scheduler.getAutoTradeEnabled(),
        trailingStopEnabled: scheduler.getTrailingStopEnabled(),
        timestamp: bot.timestamp || new Date().toISOString(),
      });
    } catch (err) {
      res.status(502).json({ success: false, error: err.response?.data?.error || err.message });
    }
  });

  router.post('/trades/reset', rateLimit, requireAdmin, (req, res) => {
    try {
      const tradeStore = require('../../tradeStore');
      const result = tradeStore.resetAll();
      logger.info(`Reset de operações por ${req.auth?.user?.email || 'admin'}: ${JSON.stringify(result)}`);
      res.json({ success: true, deleted: result });
    } catch (e) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  return router;
}

module.exports = { createAdminRouter };
