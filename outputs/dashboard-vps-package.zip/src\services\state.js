'use strict';

/**
 * STATE — Configuração e estado compartilhado entre módulos.
 *
 * Este módulo centraliza:
 *   1. Configuração dos ativos (ASSETS, ASSET_MAX_SCORE)
 *   2. Cache genérico de dados de mercado (cache, isCacheValid)
 *   3. Configuração de sessões de mercado (SESSION_HOURS, ASSET_BEST_SESSIONS)
 *
 * Por que um módulo separado?
 *   Node.js garante que o mesmo `require()` retorna SEMPRE o mesmo objeto em memória
 *   (singleton por módulo). Isso significa que qualquer módulo que importe `cache`
 *   daqui estará lendo e escrevendo no MESMO objeto — sem cópias, sem dessincronização.
 *   É a forma idiomática de compartilhar estado mutável entre módulos em Node.js.
 *
 * Exportações:
 *   - ASSETS              { btc, xauusd, eurusd, usdjpy }   → config por ativo
 *   - ASSET_MAX_SCORE     { btc: 17, xauusd: 16, ... }      → score máximo teórico
 *   - CACHE_TTL_MS        number                            → TTL padrão do cache (15min)
 *   - cache               { [key]: { data, updatedAt } }    → estado mutável em memória
 *   - isCacheValid(key)   → boolean                        → verifica se cache está fresco
 *   - SESSION_HOURS       { tokyo, london, ny, overlap }    → horários UTC das sessões
 *   - ASSET_BEST_SESSIONS { btc, xauusd, eurusd, usdjpy }  → sessões ideais por ativo
 */

// ─── ATIVOS ───────────────────────────────────────────────────────────────────

/**
 * Configuração dos 4 ativos suportados.
 *   symbol:        Par de trading (exibição)
 *   name:          Nome do instrumento (MT5/broker)
 *   fallbackPrice: Preço de referência quando não há dados reais
 *   vol:           Volatilidade típica (usada para geração de dados simulados)
 *   decimals:      Casas decimais do preço
 *   alwaysOpen:    true = mercado 24/7 (BTC), false = segue horário forex
 */
const ASSETS = {
  btc:    { symbol: 'BTC/USD',  name: 'BTCUSD',  fallbackPrice: 67000,  vol: 500,   decimals: 0, alwaysOpen: true  },
  xauusd: { symbol: 'XAU/USD',  name: 'XAUUSD',  fallbackPrice: 3300,   vol: 40,    decimals: 2, alwaysOpen: false },
  eurusd: { symbol: 'EUR/USD',  name: 'EURUSD',  fallbackPrice: 1.095,  vol: 0.004, decimals: 5, alwaysOpen: false },
  usdjpy: { symbol: 'USD/JPY',  name: 'USDJPY',  fallbackPrice: 160.0,  vol: 0.6,   decimals: 3, alwaysOpen: false },
};

/**
 * Score máximo teórico por ativo.
 * Score base 7 + bônus universais 7 + bônus específicos por ativo.
 * Não depende de disponibilidade de API — é o teto fixo para normalização.
 */
const ASSET_MAX_SCORE = { eurusd: 14, usdjpy: 15, xauusd: 16, btc: 17 };

// ─── CACHE DE DADOS DE MERCADO ────────────────────────────────────────────────

/**
 * TTL (Time To Live) padrão do cache de candles: 15 minutos.
 * Usado em isCacheValid e em outros módulos que verificam frescor dos dados.
 */
const CACHE_TTL_MS = 15 * 60 * 1000;

/**
 * Cache genérico de dados de mercado.
 * Estrutura: { [assetKey]: { data: object|null, updatedAt: number|null } }
 *
 * Este objeto é MUTÁVEL e COMPARTILHADO — qualquer módulo que o importar
 * estará lendo/escrevendo no mesmo objeto em memória (Node.js singleton).
 * Isso é intencional: permite que dataSources escreva e signals leia sem acoplamento direto.
 */
const cache = {};
Object.keys(ASSETS).forEach(k => { cache[k] = { data: null, updatedAt: null }; });

/**
 * Verifica se o cache de um ativo ainda está dentro do TTL.
 * @param {string} key - Chave do ativo (ex: 'btc', 'eurusd')
 * @returns {boolean}
 */
function isCacheValid(key) {
  const e = cache[key];
  return !!(e && e.data && e.updatedAt && (Date.now() - e.updatedAt) < CACHE_TTL_MS);
}

// ─── SESSÕES DE MERCADO ───────────────────────────────────────────────────────

/**
 * Horários das sessões principais (UTC).
 * Forex opera em três grandes sessões com sobreposições.
 * O "overlap" London+NY é o período de maior liquidez e spreads menores.
 */
const SESSION_HOURS = {
  tokyo:   { open: 0,  close: 9  },
  london:  { open: 7,  close: 16 },
  ny:      { open: 12, close: 21 },
  overlap: { open: 13, close: 16 },  // London + NY — maior volume
};

/**
 * Sessões ideais de operação por ativo.
 * BTC opera bem em qualquer sessão com volume, mas prefere London/NY.
 * XAU/USD: melhor no overlap (London+NY) onde ouro tem maior liquidez.
 * EUR/USD: clássico par de London/NY.
 * USD/JPY: abre bem em Tokyo (par do iene) e London.
 */
const ASSET_BEST_SESSIONS = {
  btc:    ['london', 'ny'],
  xauusd: ['overlap', 'london', 'ny'],
  eurusd: ['london', 'ny', 'overlap'],
  usdjpy: ['tokyo', 'london'],
};

// ─── EXPORTS ──────────────────────────────────────────────────────────────────

module.exports = {
  ASSETS,
  ASSET_MAX_SCORE,
  CACHE_TTL_MS,
  cache,
  isCacheValid,
  SESSION_HOURS,
  ASSET_BEST_SESSIONS,
};
